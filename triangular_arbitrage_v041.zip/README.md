# TRIANGULAR ARBITRAGE v0.4.1

Binance Spot multi-triangle scanner. Public market data only; no API keys, account access, or orders.

## Changes from v0.4

- Calculates **gross** result without fees and **net** result with the assumed 0.1% fee on each of three legs.
- Displays gross and net percentages and net USDT result.
- Saves the best route from every saved snapshot to `snapshot_best`, in addition to the top 20 routes in `scan_results`.
- Shows why triangles are not ready: missing book, stale book, or excessive timestamp skew.
- A positive signal is not closed merely because its order book temporarily becomes missing, stale, or out of sync. It is closed only after a valid recalculation shows that the route is no longer positive.
- Uses a separate database: `triangular_arbitrage_v041.db`. The v0.4 database is not modified.

## Baseline settings

- Capital: 1000 USDT
- Assumed fee: 0.1% per conversion leg
- Up to 100 USDT-started triangles
- Top-20 partial order books, 100 ms stream
- Maximum book age: 1500 ms
- Maximum timestamp skew: 750 ms
- Up to 300 unique symbols, 30 streams per WebSocket connection

## Install and run (Termux / Linux)

```bash
python -m pip install -r requirements.txt
python triangular_arbitrage.py
```

Stop with `Ctrl+C`.

## SQLite tables

- `scan_sessions`: scanner sessions.
- `scan_results`: top 20 valid routes per saved snapshot, including gross and net result.
- `snapshot_best`: one best net route per saved snapshot, with gross and net figures.
- `signal_events`: positive net signals with duration and maximum observed result.

Example query:

```bash
python - <<'PY'
import sqlite3
db = sqlite3.connect('triangular_arbitrage_v041.db')
for row in db.execute('''SELECT ts_utc, triangle, direction,
                                gross_profit_pct, net_profit_pct
                         FROM snapshot_best
                         ORDER BY net_profit_pct DESC LIMIT 20'''):
    print(row)
db.close()
PY
```

## Calculation notes and limitations

Gross and net values are simulated independently against the same currently visible top-20 book depth. Net applies `FEE_RATE = 0.001` to each of the three conversions. The assumed fee is not fetched from an account and does not include account-specific BNB discounts, VIP rates, special fees, or symbol-specific promotions.

The calculation still does not enforce Binance symbol filters (`LOT_SIZE`, `PRICE_FILTER`, `MIN_NOTIONAL`), account-specific fees, order latency between legs, partial fills, queue position, or execution guarantees. A positive snapshot is not proof that an arbitrage can be executed profitably. The 24-hour quote-volume ranking remains a candidate-selection heuristic and does not normalize quote currencies.

This version is READ-ONLY and does not place orders.
