# TRIANGULAR ARBITRAGE v0.4 — MULTI-TRIANGLE SCANNER

Binance Spot public-market-data scanner for USDT-started triangular routes. It is **READ-ONLY**: no API keys, account access, or orders are used.

## What changed in v0.4

- Downloads currently trading Binance Spot symbols and 24-hour ticker statistics.
- Finds triangular combinations of the form `USDT -> A -> B -> USDT` and the reverse route.
- Selects up to 100 candidate triangles (up to 300 unique symbols), prioritizing markets with stronger 24-hour quote-volume ranks.
- Subscribes to top-20 partial order books using multiple combined WebSocket connections.
- Simulates both directions using the correct bid/ask side, visible top-20 depth, and the assumed fee on all three conversion legs.
- Displays the best 20 routes, including negative results; positive results are green.
- Saves periodic top results to SQLite and records each positive signal as an event with start/end time, duration, maximum profit, and observation count.

The 24-hour volume ranking is only a candidate-selection heuristic. Quote volumes from different quote currencies are not directly comparable, so it is not a precise liquidity valuation. This scanner starts and ends in USDT; it does not search triangles that start in other assets.

## Requirements

- Python 3.9+
- `websockets>=12,<16`

Install:

```bash
python -m pip install -r requirements.txt
```

Run:

```bash
python triangular_arbitrage.py
```

Stop with `Ctrl+C`.

## Configuration

Settings are at the top of `triangular_arbitrage.py`:

- `START_USDT = 1000.0`
- `FEE_RATE = 0.001` (0.1% per leg; change to your actual taker/maker assumptions)
- `MAX_TRIANGLES = 100`
- `MAX_STREAMS = 300`
- `STREAMS_PER_CONNECTION = 30`
- `MAX_BOOK_AGE_MS = 1500`
- `MAX_BOOK_SKEW_MS = 750`

The scanner uses public Binance endpoints. Binance availability, network restrictions, and WebSocket limits may vary. If some WebSocket shards reconnect, the dashboard shows the connected count and the latest error.

## SQLite statistics

The database is `triangular_arbitrage_v04.db` in the current working directory. It is separate from v0.3's `triangular_arbitrage.db`; the old database is not changed.

Tables:

- `scan_sessions`: each program run and the selected universe size.
- `scan_results`: top 20 valid routes saved every 5 seconds.
- `signal_events`: positive routes tracked from first positive observation until they stop being positive (or the run stops).

Useful read-only queries:

```bash
python - <<'PY'
import sqlite3
con = sqlite3.connect('triangular_arbitrage_v04.db')
print('Best saved result:')
print(con.execute('''SELECT ts_utc, triangle, direction, profit_usdt, profit_pct
FROM scan_results ORDER BY profit_pct DESC LIMIT 1''').fetchone())
print('Positive signal events:')
print(con.execute('''SELECT COUNT(*), MAX(max_profit_pct), AVG(max_profit_pct),
                     MAX(duration_seconds)
FROM signal_events''').fetchone())
print('Top signal events:')
for row in con.execute('''SELECT start_ts, triangle, direction, max_profit_usdt,
                          max_profit_pct, duration_seconds, observations
FROM signal_events ORDER BY max_profit_pct DESC LIMIT 20'''):
    print(row)
con.close()
PY
```

## Important limitations

This is a market-monitoring and simulation tool, not an execution engine. A positive simulated route is not a guaranteed executable arbitrage. The calculation does not yet apply Binance symbol filters (`LOT_SIZE`, `PRICE_FILTER`, `MIN_NOTIONAL`), account-specific fee discounts, latency between three orders, partial fills, or queue position. Top-20 depth is a snapshot estimate. Do not treat the output as a promise of profit or as a live trading instruction.
