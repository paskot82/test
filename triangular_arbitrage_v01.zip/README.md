# Triangular Arbitrage Monitor v0.1

Binance Spot triangular-arbitrage **READ-ONLY simulator**. It does not request API keys, access an account, or place/cancel orders.

## Triangle

- `BTCUSDT` = BTC priced in USDT
- `ETCUSDT` = ETC priced in USDT
- `ETCBTC` = ETC priced in BTC (the exchange's symbol is `ETCBTC`, even if the pair is informally described as BTC/ETC)

Both cycles are evaluated:

1. USDT -> BTC -> ETC -> USDT
2. USDT -> ETC -> BTC -> USDT

The simulator walks the currently visible top 20 bid/ask levels for each leg and deducts the configured assumed fee on every conversion. A positive profit percentage is displayed in **green**, a negative one in red.

## Requirements

- Python 3.9+
- Internet connection
- Termux, Ubuntu, or another Linux environment

## Termux / Linux installation

```sh
pkg update
pkg install python -y       # Termux; on Ubuntu use: sudo apt install python3 python3-pip
cd ~/storage/downloads/triangular_arbitrage
python -m pip install -r requirements.txt
python triangular_arbitrage.py
```

If you unpacked the archive elsewhere, change to that directory first.

## Settings

Edit the constants at the top of `triangular_arbitrage.py`:

- `START_USDT = 1000.0` — simulated starting capital.
- `FEE_RATE = 0.001` — assumed fee per leg (0.1%). Replace with the actual account fee before interpreting results.
- `MAX_BOOK_AGE_MS` and `MAX_BOOK_SKEW_MS` — freshness/synchronization limits.

Set `NO_COLOR=1` to disable ANSI colors.

## Important limitations

- This is a market-data simulation, not an execution engine or a promise of risk-free profit.
- Binance symbol availability is checked at startup. If one leg is not active for the Binance Spot endpoint available to your region, startup stops with an explanation.
- Uses the partial depth stream's top 20 levels; it is not a full locally reconstructed order book.
- It does not yet apply exchange quantity step sizes, minimum quantity/notional filters, actual commission-asset rules, or order execution latency/partial fills.
- A green number is an estimate from displayed depth, not a guaranteed executable profit.

SQLite results are stored in `triangular_arbitrage.db` in the working directory.
