#!/usr/bin/env python3
"""
Crypto Market Monitor v0.3
Public market data only. Read-only monitoring and educational simulation.
No account access, API keys, or order execution.
"""
import asyncio
import json
import os
import sqlite3
import time
from datetime import datetime, timezone

import websockets

VERSION = "0.3"
SYMBOLS = ("BTCUSDT", "ETHUSDT", "ETHBTC")
FEE_RATE = 0.001                 # Assumed fee per leg (0.1%); simulation placeholder only
MAX_QUOTE_AGE_MS = 3000
MAX_PAIR_SKEW_MS = 1500
DISPLAY_INTERVAL = 1.0
DB_PATH = "market_monitor.db"
BINANCE_URL = (
    "wss://stream.binance.com:9443/stream?streams="
    + "/".join(s.lower() + "@bookTicker" for s in SYMBOLS)
)
BYBIT_URL = "wss://stream.bybit.com/v5/public/spot"
BYBIT_TOPICS = ["orderbook.1." + s for s in SYMBOLS]

latest = {}
stats = {}
connection = {"BINANCE": "disconnected", "BYBIT": "disconnected"}
last_db_write = {}
db = None


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def init_db():
    global db
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("""
        CREATE TABLE IF NOT EXISTS quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts_utc TEXT NOT NULL,
            exchange TEXT NOT NULL,
            symbol TEXT NOT NULL,
            bid REAL, bid_size REAL, ask REAL, ask_size REAL,
            age_ms REAL,
            message_type TEXT
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS comparisons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts_utc TEXT NOT NULL,
            symbol TEXT NOT NULL,
            direction TEXT NOT NULL,
            gross_pct REAL,
            estimated_net_pct REAL,
            buy_ask REAL,
            sell_bid REAL,
            quote_skew_ms REAL
        )
    """)
    db.commit()


def record_message(exchange, symbol, message_type="update"):
    now = time.monotonic()
    key = (exchange, symbol)
    item = stats.setdefault(key, {
        "messages": 0, "updates": 0, "first_seen": now,
        "last_seen": now, "previous_seen": None,
        "interval_sum": 0.0, "interval_count": 0,
        "min_interval": None, "max_interval": None,
    })
    previous = item["last_seen"]
    interval = now - previous
    if item["messages"] > 0 and interval >= 0:
        item["interval_sum"] += interval
        item["interval_count"] += 1
        item["min_interval"] = interval if item["min_interval"] is None else min(item["min_interval"], interval)
        item["max_interval"] = interval if item["max_interval"] is None else max(item["max_interval"], interval)
    item["messages"] += 1
    item["updates"] += 1
    item["previous_seen"] = previous
    item["last_seen"] = now
    return now


def save_quote(exchange, symbol, quote, received, message_type="update"):
    latest[(exchange, symbol)] = {
        **quote, "received": received, "message_type": message_type
    }
    # Persist at most once per second per exchange/symbol to keep the DB compact.
    key = (exchange, symbol)
    now = time.monotonic()
    if now - last_db_write.get(key, 0) >= 1.0:
        age_ms = max(0.0, (now - received) * 1000)
        db.execute(
            """INSERT INTO quotes
            (ts_utc, exchange, symbol, bid, bid_size, ask, ask_size, age_ms, message_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (utc_now(), exchange, symbol, quote["bid"], quote["bid_size"],
             quote["ask"], quote["ask_size"], age_ms, message_type)
        )
        db.commit()
        last_db_write[key] = now


async def run_binance():
    delay = 1
    while True:
        try:
            connection["BINANCE"] = "connecting"
            async with websockets.connect(BINANCE_URL, ping_interval=20, ping_timeout=20) as ws:
                connection["BINANCE"] = "connected"
                delay = 1
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                        data = msg.get("data", {})
                        symbol = data.get("s")
                        if symbol not in SYMBOLS:
                            continue
                        received = record_message("BINANCE", symbol)
                        quote = {
                            "bid": float(data["b"]),
                            "bid_size": float(data["B"]),
                            "ask": float(data["a"]),
                            "ask_size": float(data["A"]),
                        }
                        save_quote("BINANCE", symbol, quote, received, "bookTicker")
                    except (ValueError, KeyError, TypeError):
                        continue
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            connection["BINANCE"] = "reconnecting: " + str(exc)[:55]
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)


async def bybit_app_ping(ws):
    while True:
        await asyncio.sleep(20)
        await ws.send(json.dumps({"op": "ping"}))


async def run_bybit():
    delay = 1
    # Maintain best known top-of-book levels across Bybit snapshot/delta messages.
    book = {s: {"bid": None, "bid_size": None, "ask": None, "ask_size": None} for s in SYMBOLS}
    while True:
        ping_task = None
        try:
            connection["BYBIT"] = "connecting"
            async with websockets.connect(BYBIT_URL, ping_interval=None, close_timeout=5) as ws:
                connection["BYBIT"] = "connected"
                delay = 1
                await ws.send(json.dumps({"op": "subscribe", "args": BYBIT_TOPICS}))
                ping_task = asyncio.create_task(bybit_app_ping(ws))
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                        topic = msg.get("topic", "")
                        if not topic.startswith("orderbook.1."):
                            continue
                        data = msg.get("data") or {}
                        symbol = data.get("s")
                        if symbol not in SYMBOLS:
                            continue
                        kind = msg.get("type", "update")
                        state = book[symbol]
                        # A snapshot replaces the book; a delta changes only supplied sides.
                        if kind == "snapshot":
                            state.update({"bid": None, "bid_size": None, "ask": None, "ask_size": None})
                        bids = data.get("b") or []
                        asks = data.get("a") or []
                        if bids:
                            p, q = float(bids[0][0]), float(bids[0][1])
                            if q == 0:
                                state["bid"] = state["bid_size"] = None
                            else:
                                state["bid"], state["bid_size"] = p, q
                        if asks:
                            p, q = float(asks[0][0]), float(asks[0][1])
                            if q == 0:
                                state["ask"] = state["ask_size"] = None
                            else:
                                state["ask"], state["ask_size"] = p, q
                        if None in (state["bid"], state["ask"], state["bid_size"], state["ask_size"]):
                            continue
                        received = record_message("BYBIT", symbol, kind)
                        save_quote("BYBIT", symbol, dict(state), received, kind)
                    except (ValueError, KeyError, TypeError, IndexError):
                        continue
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            connection["BYBIT"] = "reconnecting: " + str(exc)[:55]
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)
        finally:
            if ping_task:
                ping_task.cancel()


def quote_age_ms(q, now):
    return max(0.0, (now - q["received"]) * 1000)


def estimate(buy, sell):
    gross = (sell["bid"] / buy["ask"] - 1.0) * 100.0
    net = ((sell["bid"] * (1.0 - FEE_RATE)) /
           (buy["ask"] * (1.0 + FEE_RATE)) - 1.0) * 100.0
    return gross, net


def fmt_num(value, decimals=8):
    if value is None:
        return "-"
    return f"{value:.{decimals}f}".rstrip("0").rstrip(".")


def render():
    now = time.monotonic()
    lines = [
        f"CRYPTO MARKET MONITOR v{VERSION} | PUBLIC DATA / READ-ONLY / SIMULATION",
        f"UTC: {utc_now()}   Assumed fee: {FEE_RATE*100:.3f}% per leg   "
        f"Max age: {MAX_QUOTE_AGE_MS} ms   Max pair skew: {MAX_PAIR_SKEW_MS} ms",
        f"Connections: BINANCE: {connection['BINANCE']} | BYBIT: {connection['BYBIT']}",
        "",
        "PAIR     EXCHANGE   BID                  ASK                  AGE       STATUS",
        "-" * 88,
    ]
    for symbol in SYMBOLS:
        pair_quotes = {}
        for exchange in ("BINANCE", "BYBIT"):
            q = latest.get((exchange, symbol))
            if q:
                age = quote_age_ms(q, now)
                status = "fresh" if age <= MAX_QUOTE_AGE_MS else "STALE"
                lines.append(
                    f"{symbol:<8} {exchange:<9} {fmt_num(q['bid']):<20} "
                    f"{fmt_num(q['ask']):<20} {age:7.0f} ms {status}"
                )
                pair_quotes[exchange] = q
            else:
                lines.append(f"{symbol:<8} {exchange:<9} {'-':<20} {'-':<20} {'-':>7}    NO DATA")

        b = pair_quotes.get("BINANCE")
        y = pair_quotes.get("BYBIT")
        if not b or not y:
            lines.append("  Comparison: waiting for both exchanges")
        else:
            age_b, age_y = quote_age_ms(b, now), quote_age_ms(y, now)
            skew = abs(b["received"] - y["received"]) * 1000
            if max(age_b, age_y) > MAX_QUOTE_AGE_MS or skew > MAX_PAIR_SKEW_MS:
                reason = "stale quote" if max(age_b, age_y) > MAX_QUOTE_AGE_MS else "time skew"
                lines.append(f"  Comparison: WAITING ({reason}; skew {skew:.0f} ms)")
            else:
                g1, n1 = estimate(b, y)  # buy Binance ask, sell Bybit bid
                g2, n2 = estimate(y, b)  # buy Bybit ask, sell Binance bid
                lines.append(f"  BUY BINANCE -> SELL BYBIT: gross {g1:+.4f}% | estimated net {n1:+.4f}%")
                lines.append(f"  BUY BYBIT   -> SELL BINANCE: gross {g2:+.4f}% | estimated net {n2:+.4f}%")
                best = max(n1, n2)
                lines.append(f"  Better displayed estimate: {best:+.4f}% (not an executable signal)")
                for direction, gross, net, buy, sell in (
                    ("BINANCE->BYBIT", g1, n1, b, y),
                    ("BYBIT->BINANCE", g2, n2, y, b),
                ):
                    db.execute(
                        """INSERT INTO comparisons
                        (ts_utc, symbol, direction, gross_pct, estimated_net_pct,
                         buy_ask, sell_bid, quote_skew_ms)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (utc_now(), symbol, direction, gross, net, buy["ask"], sell["bid"], skew)
                    )
        lines.append("")
    lines.extend([
        "-" * 88,
        "UPDATE DIAGNOSTICS (messages received; average interval is approximate):",
    ])
    for symbol in SYMBOLS:
        for exchange in ("BINANCE", "BYBIT"):
            st = stats.get((exchange, symbol))
            if not st:
                lines.append(f"  {exchange:<7} {symbol:<8} messages: 0 | waiting for first update")
                continue
            elapsed = max(0.001, now - st["first_seen"])
            avg = (st["interval_sum"] / st["interval_count"] * 1000) if st["interval_count"] else 0
            last_age = max(0.0, (now - st["last_seen"]) * 1000)
            mn = st["min_interval"] * 1000 if st["min_interval"] is not None else 0
            mx = st["max_interval"] * 1000 if st["max_interval"] is not None else 0
            lines.append(
                f"  {exchange:<7} {symbol:<8} msgs: {st['messages']:<7} "
                f"rate: {st['messages']/elapsed:6.2f}/s  last: {last_age:6.0f} ms  "
                f"interval avg/min/max: {avg:.0f}/{mn:.0f}/{mx:.0f} ms"
            )
    lines.extend([
        "",
        f"SQLite: {os.path.abspath(DB_PATH)}",
        "Ctrl+C to stop. No account access, API keys, or order execution.",
    ])
    db.commit()
    return "\n".join(lines)


async def dashboard():
    while True:
        print("\033[H\033[2J", end="")
        print(render(), flush=True)
        await asyncio.sleep(DISPLAY_INTERVAL)


async def main():
    init_db()
    print("\033[2J\033[HStarting public market-data streams...", flush=True)
    tasks = [
        asyncio.create_task(run_binance()),
        asyncio.create_task(run_bybit()),
        asyncio.create_task(dashboard()),
    ]
    try:
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if db:
            db.commit()
            db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped.")
