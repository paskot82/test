#!/usr/bin/env python3
"""Binance Spot multi-triangle arbitrage scanner. Public data only; no orders."""
import asyncio
import json
import os
import sqlite3
import time
import urllib.request
from datetime import datetime, timezone
from itertools import combinations

import websockets

VERSION = "0.4"
START_USDT = 1000.0
FEE_RATE = 0.001                 # Assumed fee per conversion leg (0.1%)
DEPTH_LEVELS = 20
MAX_BOOK_AGE_MS = 1500
MAX_BOOK_SKEW_MS = 750
DISPLAY_INTERVAL = 1.0
SAVE_INTERVAL = 5.0
MAX_TRIANGLES = 100
MAX_STREAMS = 300
STREAMS_PER_CONNECTION = 30
TOP_DISPLAY = 20
DB_PATH = "triangular_arbitrage_v04.db"
USE_COLOR = os.environ.get("NO_COLOR") is None

EXCHANGE_INFO_URL = "https://api.binance.com/api/v3/exchangeInfo"
TICKER_24H_URL = "https://api.binance.com/api/v3/ticker/24hr"
WS_BASE_URL = "wss://stream.binance.com:9443/stream?streams="

# market_by_assets[frozenset((asset_a, asset_b))] -> market metadata
market_by_assets = {}
triangles = []
books = {}
connection_states = []
last_errors = []
db = None
active_signals = {}
last_save = 0.0
session_id = None


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def color(text, code):
    if not USE_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"


def pct_text(value):
    value_text = f"{value:+.4f}%"
    if value > 0:
        return color(value_text, "32;1")
    if value < 0:
        return color(value_text, "31")
    return value_text


def http_json(url, timeout=25):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": f"TriangularArbitrageScanner/{VERSION}"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def discover_triangles():
    """Build USDT-started triangles, ranked by the liquidity rank of their legs."""
    print("Downloading Binance Spot market list and 24h ticker statistics...", flush=True)
    exchange_info = http_json(EXCHANGE_INFO_URL)
    ticker_rows = http_json(TICKER_24H_URL)
    ticker_by_symbol = {row.get("symbol"): row for row in ticker_rows}

    markets = {}
    for item in exchange_info.get("symbols", []):
        if item.get("status") != "TRADING":
            continue
        if item.get("isSpotTradingAllowed") is False:
            continue
        base = item.get("baseAsset")
        quote = item.get("quoteAsset")
        symbol = item.get("symbol")
        if not base or not quote or not symbol or base == quote:
            continue
        key = frozenset((base, quote))
        ticker = ticker_by_symbol.get(symbol, {})
        try:
            quote_volume = float(ticker.get("quoteVolume", 0.0))
        except (TypeError, ValueError):
            quote_volume = 0.0
        markets[key] = {
            "symbol": symbol,
            "base": base,
            "quote": quote,
            "quote_volume": quote_volume,
        }

    # Rank markets independently by reported 24h quote volume. This is a
    # heuristic for candidate selection, not a cross-quote currency valuation.
    ranked = sorted(markets.values(), key=lambda m: m["quote_volume"], reverse=True)
    rank_by_symbol = {m["symbol"]: i + 1 for i, m in enumerate(ranked)}

    usdt_assets = sorted(
        m["base"] for m in markets.values() if m["quote"] == "USDT"
    )
    candidates = []
    for asset_a, asset_b in combinations(usdt_assets, 2):
        market_a = markets.get(frozenset(("USDT", asset_a)))
        market_b = markets.get(frozenset(("USDT", asset_b)))
        cross = markets.get(frozenset((asset_a, asset_b)))
        if not (market_a and market_b and cross):
            continue
        symbols = (market_a["symbol"], market_b["symbol"], cross["symbol"])
        rank_score = sum(rank_by_symbol.get(s, len(rank_by_symbol) + 1) for s in symbols)
        candidates.append({
            "asset_a": asset_a,
            "asset_b": asset_b,
            "symbols": symbols,
            "triangle": f"USDT-{asset_a}-{asset_b}-USDT",
            "rank_score": rank_score,
        })

    candidates.sort(key=lambda item: item["rank_score"])
    selected = []
    selected_symbols = set()
    for candidate in candidates:
        new_symbols = set(candidate["symbols"]) - selected_symbols
        if len(selected) >= MAX_TRIANGLES:
            break
        if len(selected_symbols) + len(new_symbols) > MAX_STREAMS:
            continue
        selected.append(candidate)
        selected_symbols.update(new_symbols)

    if not selected:
        raise RuntimeError("No USDT-started Spot triangles found among currently trading Binance pairs.")

    global market_by_assets, triangles
    market_by_assets = markets
    triangles = selected
    print(f"Discovered {len(candidates)} possible USDT triangles; selected {len(triangles)}.", flush=True)
    print(f"Subscribing to {len(selected_symbols)} unique order books.", flush=True)
    print("Selected triangle examples:", flush=True)
    for item in triangles[:10]:
        print(f"  {item['triangle']}  (liquidity-rank score {item['rank_score']})", flush=True)
    return sorted(selected_symbols)


def init_db():
    global db, session_id
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=NORMAL")
    db.execute("""CREATE TABLE IF NOT EXISTS scan_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        start_ts TEXT NOT NULL,
        end_ts TEXT,
        triangle_count INTEGER NOT NULL,
        symbol_count INTEGER NOT NULL,
        start_usdt REAL NOT NULL,
        fee_rate REAL NOT NULL,
        status TEXT NOT NULL
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS scan_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        ts_utc TEXT NOT NULL,
        triangle TEXT NOT NULL,
        direction TEXT NOT NULL,
        start_usdt REAL NOT NULL,
        final_usdt REAL,
        profit_usdt REAL,
        profit_pct REAL,
        status TEXT NOT NULL
    )""")
    db.execute("""CREATE INDEX IF NOT EXISTS idx_scan_results_pct
        ON scan_results(profit_pct)""")
    db.execute("""CREATE INDEX IF NOT EXISTS idx_scan_results_ts
        ON scan_results(ts_utc)""")
    db.execute("""CREATE TABLE IF NOT EXISTS signal_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        triangle TEXT NOT NULL,
        direction TEXT NOT NULL,
        start_ts TEXT NOT NULL,
        last_seen_ts TEXT NOT NULL,
        end_ts TEXT,
        duration_seconds REAL,
        max_profit_usdt REAL NOT NULL,
        max_profit_pct REAL NOT NULL,
        observations INTEGER NOT NULL,
        status TEXT NOT NULL
    )""")
    # A process killed without cleanup leaves an open event; mark it interrupted.
    db.execute("""UPDATE signal_events SET status='interrupted',
        end_ts=COALESCE(end_ts, last_seen_ts),
        duration_seconds=MAX(0, (julianday(COALESCE(end_ts, last_seen_ts)) - julianday(start_ts)) * 86400)
        WHERE end_ts IS NULL""")
    db.commit()
    cur = db.execute("""INSERT INTO scan_sessions
        (start_ts, triangle_count, symbol_count, start_usdt, fee_rate, status)
        VALUES (?, ?, ?, ?, ?, 'running')""",
        (utc_now(), len(triangles), len({s for t in triangles for s in t["symbols"]}), START_USDT, FEE_RATE))
    session_id = cur.lastrowid
    db.commit()


def parse_book(data):
    try:
        bids = [(float(p), float(q)) for p, q in data.get("bids", []) if float(q) > 0]
        asks = [(float(p), float(q)) for p, q in data.get("asks", []) if float(q) > 0]
    except (TypeError, ValueError):
        return None
    bids.sort(key=lambda x: x[0], reverse=True)
    asks.sort(key=lambda x: x[0])
    if not bids or not asks:
        return None
    return {"bids": bids[:DEPTH_LEVELS], "asks": asks[:DEPTH_LEVELS], "received": time.monotonic()}


def buy_base(quote_amount, asks, fee_rate):
    remaining = quote_amount
    received_base = 0.0
    for price, available_base in asks:
        take = min(available_base, remaining / price)
        if take <= 0:
            continue
        received_base += take
        remaining -= take * price
        if remaining <= max(1e-12, quote_amount * 1e-12):
            remaining = 0.0
            break
    if remaining > max(1e-10, quote_amount * 1e-9):
        return None
    return received_base * (1.0 - fee_rate)


def sell_base(base_amount, bids, fee_rate):
    remaining = base_amount
    received_quote = 0.0
    for price, available_base in bids:
        take = min(available_base, remaining)
        if take <= 0:
            continue
        received_quote += take * price
        remaining -= take
        if remaining <= max(1e-12, base_amount * 1e-12):
            remaining = 0.0
            break
    if remaining > max(1e-10, base_amount * 1e-9):
        return None
    return received_quote * (1.0 - fee_rate)


def convert(amount, from_asset, to_asset, market, fee_rate):
    """Convert using the correct side of a spot order book and visible depth."""
    book = books.get(market["symbol"])
    if not book:
        return None
    if from_asset == market["quote"] and to_asset == market["base"]:
        return buy_base(amount, book["asks"], fee_rate)
    if from_asset == market["base"] and to_asset == market["quote"]:
        return sell_base(amount, book["bids"], fee_rate)
    return None


def triangle_ready(triangle):
    symbols = triangle["symbols"]
    if not all(symbol in books for symbol in symbols):
        return False
    now = time.monotonic()
    received = [books[s]["received"] for s in symbols]
    ages = [(now - value) * 1000 for value in received]
    return max(ages) <= MAX_BOOK_AGE_MS and (max(received) - min(received)) * 1000 <= MAX_BOOK_SKEW_MS


def simulate_triangle(triangle):
    a = triangle["asset_a"]
    b = triangle["asset_b"]
    market_usdt_a = market_by_assets[frozenset(("USDT", a))]
    market_usdt_b = market_by_assets[frozenset(("USDT", b))]
    market_ab = market_by_assets[frozenset((a, b))]
    results = []

    # USDT -> A -> B -> USDT
    amount_a = convert(START_USDT, "USDT", a, market_usdt_a, FEE_RATE)
    amount_b = convert(amount_a, a, b, market_ab, FEE_RATE) if amount_a is not None else None
    final_ab = convert(amount_b, b, "USDT", market_usdt_b, FEE_RATE) if amount_b is not None else None
    # USDT -> B -> A -> USDT
    amount_b2 = convert(START_USDT, "USDT", b, market_usdt_b, FEE_RATE)
    amount_a2 = convert(amount_b2, b, a, market_ab, FEE_RATE) if amount_b2 is not None else None
    final_ba = convert(amount_a2, a, "USDT", market_usdt_a, FEE_RATE) if amount_a2 is not None else None

    for direction, final in ((f"USDT>{a}>{b}>USDT", final_ab), (f"USDT>{b}>{a}>USDT", final_ba)):
        if final is None:
            results.append({"triangle": triangle["triangle"], "direction": direction,
                            "final": None, "profit": None, "pct": None,
                            "status": "insufficient visible depth"})
        else:
            profit = final - START_USDT
            results.append({"triangle": triangle["triangle"], "direction": direction,
                            "final": final, "profit": profit,
                            "pct": profit / START_USDT * 100.0, "status": "simulated"})
    return results


async def market_data_worker(symbols, worker_id):
    delay = 1
    stream_names = [f"{symbol.lower()}@depth20@100ms" for symbol in symbols]
    url = WS_BASE_URL + "/".join(stream_names)
    while True:
        try:
            connection_states[worker_id] = "connecting"
            async with websockets.connect(url, ping_interval=20, ping_timeout=20, close_timeout=5,
                                          open_timeout=15, max_size=2**22) as ws:
                connection_states[worker_id] = "connected"
                last_errors[worker_id] = ""
                delay = 1
                async for raw in ws:
                    try:
                        message = json.loads(raw)
                        data = message.get("data", {})
                        stream_name = message.get("stream", "")
                        symbol = data.get("s") or stream_name.split("@", 1)[0].upper()
                        if symbol not in symbols:
                            continue
                        book = parse_book(data)
                        if book:
                            books[symbol] = book
                    except (ValueError, TypeError, KeyError, AttributeError):
                        continue
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            connection_states[worker_id] = "reconnecting"
            last_errors[worker_id] = str(exc)[:120]
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)


def update_signal_events(results, timestamp):
    global active_signals
    current_positive = {}
    for result in results:
        if result["pct"] is not None and result["pct"] > 0:
            key = (result["triangle"], result["direction"])
            current_positive[key] = result

    # Start or update positive signals.
    for key, result in current_positive.items():
        if key not in active_signals:
            cur = db.execute("""INSERT INTO signal_events
                (session_id, triangle, direction, start_ts, last_seen_ts,
                 max_profit_usdt, max_profit_pct, observations, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'active')""",
                (session_id, key[0], key[1], timestamp, timestamp, result["profit"], result["pct"]))
            active_signals[key] = {"id": cur.lastrowid, "start_mono": time.monotonic(),
                                   "max_profit": result["profit"], "max_pct": result["pct"], "observations": 1}
        else:
            state = active_signals[key]
            state["observations"] += 1
            state["max_profit"] = max(state["max_profit"], result["profit"])
            state["max_pct"] = max(state["max_pct"], result["pct"])
            db.execute("""UPDATE signal_events SET last_seen_ts=?, max_profit_usdt=?,
                max_profit_pct=?, observations=? WHERE id=?""",
                (timestamp, state["max_profit"], state["max_pct"], state["observations"], state["id"]))

    # Close events that are no longer positive in the current valid scan.
    for key in list(active_signals):
        if key not in current_positive:
            state = active_signals.pop(key)
            db.execute("""UPDATE signal_events SET end_ts=?, duration_seconds=?,
                status='closed' WHERE id=?""",
                (timestamp, max(0.0, time.monotonic() - state["start_mono"]), state["id"]))


def save_snapshot(results, timestamp):
    global last_save
    now = time.monotonic()
    if now - last_save < SAVE_INTERVAL:
        return
    last_save = now
    valid = [r for r in results if r["pct"] is not None]
    valid.sort(key=lambda r: r["pct"], reverse=True)
    for result in valid[:TOP_DISPLAY]:
        db.execute("""INSERT INTO scan_results
            (session_id, ts_utc, triangle, direction, start_usdt, final_usdt,
             profit_usdt, profit_pct, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (session_id, timestamp, result["triangle"], result["direction"], START_USDT,
             result["final"], result["profit"], result["pct"], result["status"]))
    db.commit()


def render(results, ready_count, total_symbols):
    lines = [
        f"TRIANGULAR ARBITRAGE v{VERSION} | BINANCE SPOT | MULTI-TRIANGLE | READ-ONLY",
        f"UTC: {utc_now()} | Capital: {START_USDT:.2f} USDT | Assumed fee: {FEE_RATE*100:.3f}% per leg",
        f"Triangles: {len(triangles)} | Symbols: {total_symbols} | Ready triangles: {ready_count}",
        f"WebSocket connections: {sum(1 for s in connection_states if s == 'connected')}/{len(connection_states)}",
        f"Max book age: {MAX_BOOK_AGE_MS} ms | Max skew: {MAX_BOOK_SKEW_MS} ms | Depth: top {DEPTH_LEVELS}",
        "",
        f"TOP {TOP_DISPLAY} ROUTES (sorted by simulated profit after assumed fees):",
        "-" * 112,
    ]
    valid = [r for r in results if r["pct"] is not None]
    valid.sort(key=lambda r: r["pct"], reverse=True)
    if not valid:
        lines.append("Waiting for fresh order books for selected triangles...")
    else:
        lines.append(f"{'TRIANGLE':<32} {'DIRECTION':<26} {'FINAL USDT':>13} {'PROFIT USDT':>13} {'PROFIT %':>11}")
        for result in valid[:TOP_DISPLAY]:
            pct = pct_text(result["pct"])
            lines.append(f"{result['triangle']:<32.32} {result['direction']:<26.26} "
                         f"{result['final']:>13.5f} {result['profit']:>+13.5f} {pct:>11}")
    positive_now = sum(1 for r in valid if r["pct"] > 0)
    lines.extend([
        "-" * 112,
        f"Positive routes right now: {positive_now} | Active positive signals: {len(active_signals)}",
        "GREEN = positive after assumed fees; RED = negative.",
        "Simulation only: no API keys, account access, or orders. Top-20 depth estimate; lot-size/min-notional filters and real fee discounts are not applied.",
        f"SQLite: {os.path.abspath(DB_PATH)}",
        "Ctrl+C to stop.",
    ])
    errors = [e for e in last_errors if e]
    if errors:
        lines.append("WebSocket error: " + errors[0])
    return "\n".join(lines)


async def dashboard(total_symbols):
    global active_signals
    while True:
        timestamp = utc_now()
        all_results = []
        ready_count = 0
        for triangle in triangles:
            if not triangle_ready(triangle):
                continue
            ready_count += 1
            all_results.extend(simulate_triangle(triangle))
        update_signal_events(all_results, timestamp)
        save_snapshot(all_results, timestamp)
        print("\033[H\033[2J", end="")
        print(render(all_results, ready_count, total_symbols), flush=True)
        await asyncio.sleep(DISPLAY_INTERVAL)


async def main():
    symbols = await asyncio.to_thread(discover_triangles)
    init_db()
    chunks = [symbols[i:i + STREAMS_PER_CONNECTION] for i in range(0, len(symbols), STREAMS_PER_CONNECTION)]
    connection_states.extend(["disconnected"] * len(chunks))
    last_errors.extend([""] * len(chunks))
    tasks = [asyncio.create_task(market_data_worker(chunk, i)) for i, chunk in enumerate(chunks)]
    tasks.append(asyncio.create_task(dashboard(len(symbols))))
    try:
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if db:
            timestamp = utc_now()
            for key, state in list(active_signals.items()):
                db.execute("""UPDATE signal_events SET end_ts=?, duration_seconds=?, status='closed_on_stop'
                    WHERE id=?""",
                    (timestamp, max(0.0, time.monotonic() - state["start_mono"]), state["id"]))
            db.execute("UPDATE scan_sessions SET end_ts=?, status='stopped' WHERE id=?", (timestamp, session_id))
            db.commit()
            db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception as exc:
        print("Startup error:", exc)
        raise
