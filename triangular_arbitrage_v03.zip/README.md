TRIANGULAR ARBITRAGE v0.3
Binance Spot | public market data | READ-ONLY simulation

IMPORTANT CHANGE
Binance removed the ETC/BTC spot pair on 2026-10-30. The previous ETC triangle therefore cannot run on Binance Spot. This version uses BTC/USDT, ETH/USDT and ETH/BTC instead.

Install in Termux:
  pkg install python -y
  pip install -r requirements.txt

Run:
  python triangular_arbitrage.py

The program checks that all three symbols are currently TRADING before connecting. It simulates both routes using visible top-20 order-book depth and an assumed 0.1% fee per leg. Set FEE_RATE in the script to your actual fee.

Positive profit percentages are displayed in bright green; negative percentages in red (ANSI terminal colors). If colors are disabled by your shell, run: unset NO_COLOR

No API keys are used. No orders are sent.

Limitations: this is an estimate using depth snapshots, not a guarantee of executable profit. It does not yet apply exchange lot-size, tick-size, min-notional or account-specific fee filters.


Version 0.3 fix: Binance combined depth20 stream payloads identify the symbol in the outer `stream` field; the monitor now reads that field when `data.s` is absent.
