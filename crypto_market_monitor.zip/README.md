# Crypto Market Monitor (read-only)

A small Python monitor that receives public Spot market data from Binance and Bybit
through WebSocket. It does not use API keys and cannot place trades.

## Requirements
- Python 3.10+
- Internet access

## Termux
```bash
pkg update
pkg install python
python -m pip install -r requirements.txt
python crypto_market_monitor.py
```

## Ubuntu
```bash
sudo apt update
sudo apt install python3 python3-venv
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python crypto_market_monitor.py
```

## Notes
- The configured Spot pairs are BTCUSDT, ETHUSDT, ETHBTC.
- A venue may reject a symbol if it is not listed/available in that market or region.
  Check the subscription response and connection output.
- The script prints best bid/ask quotes and top-level quantities. It does not build
  a full order book and does not calculate arbitrage yet.
- Reconnect uses exponential backoff (1 to 30 seconds).
- Binance Spot market streams have a 24-hour connection lifetime; reconnecting is
  expected and handled.
- Use this only as a market-data learning/monitoring tool. No private credentials
  should be added to this version.
