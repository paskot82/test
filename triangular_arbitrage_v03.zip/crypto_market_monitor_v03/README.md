# Crypto Market Monitor v0.3

Public market data monitor for Binance Spot and Bybit Spot.
**Read-only / educational simulation only.** It does not connect to user accounts,
use API keys, or place orders.

## What's new in v0.3
- Per-exchange, per-symbol message counters.
- Approximate message rate and average/minimum/maximum update intervals.
- Time since the last message for every market stream.
- Clearer stale/time-skew diagnostics.
- SQLite storage for sampled quotes and comparison observations.
- Keeps the compact terminal dashboard.

## Requirements
- Python 3.9+
- Internet connection
- `websockets` Python package

## Termux
```bash
pkg update
pkg install python
cd ~/crypto_market_monitor
pip install -r requirements.txt
python crypto_market_monitor.py
```

If you extracted the ZIP in another directory, `cd` to that directory first.

## Ubuntu
```bash
sudo apt update
sudo apt install python3 python3-venv
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python crypto_market_monitor.py
```

Stop with Ctrl+C.

## Configuration
Edit constants near the top of `crypto_market_monitor.py`:
- `SYMBOLS`: monitored pairs.
- `FEE_RATE`: assumed fee per leg. `0.001` means 0.1%; this is only a
  simulation placeholder, not your actual exchange fee.
- `MAX_QUOTE_AGE_MS`: maximum age allowed for a quote.
- `MAX_PAIR_SKEW_MS`: maximum arrival-time difference between exchange quotes.
- `DB_PATH`: SQLite database filename.

## Reading the diagnostics
- `msgs`: number of market messages processed since program start.
- `rate`: approximate messages per second since the first message.
- `last`: milliseconds since the latest message.
- `interval avg/min/max`: approximate intervals between consecutive messages.
- `STALE`: latest quote is older than `MAX_QUOTE_AGE_MS`.
- `WAITING (time skew)`: both quotes may be recent, but their local receive
  times differ by more than `MAX_PAIR_SKEW_MS`.

A low message rate does not by itself prove a connection problem: a quiet market
or a stream's update behavior can affect message frequency. Compare both the
message counters and `last` values.

## Database
`market_monitor.db` is created in the current working directory:
- `quotes`: sampled latest quotes (at most one row per exchange/symbol/second).
- `comparisons`: calculated cross-exchange estimates.

## Important limitations
The calculation uses only the top displayed bid/ask and a configurable assumed
fee. It does not model full order-book depth, actual fill sizes, slippage,
withdrawals, transfers, network costs, account restrictions, taxes, or execution.
A positive displayed estimate is not a guarantee or an executable signal.
