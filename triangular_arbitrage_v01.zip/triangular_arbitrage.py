#!/usr/bin/env python3
"""Binance Spot triangular arbitrage monitor. Public data only; no orders."""
import asyncio
import json
import os
import sqlite3
import time
import urllib.request
from datetime import datetime, timezone

import websockets

VERSION = "0.1"
SYMBOLS = ("BTCUSDT", "ETCUSDT", "ETCBTC")
START_USDT = 1000.0
FEE_RATE = 0.001                 # Assumed 0.1% per conversion leg; set to your actual fee
MAX_BOOK_AGE_MS = 1500
MAX_BOOK_SKEW_MS = 750
DISPLAY_INTERVAL = 1.0
DB_PATH = "triangular_arbitrage.db"
DEPTH_LEVELS = 20
USE_COLOR = os.environ.get("NO_COLOR") is None

STREAMS = "/".join(f"{s.lower()}@depth20@100ms" for s in SYMBOLS)
WS_URL = "wss://stream.binance.com:9443/stream?streams=" + STREAMS
EXCHANGE_INFO_URL = "https://api.binance.com/api/v3/exchangeInfo?symbols=%5B%22BTCUSDT%22%2C%22ETCUSDT%22%2C%22ETCBTC%22%5D"

books = {}
connection = "disconnected"
last_error = ""
db = None


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def color(text, code):
    if not USE_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"


def pct_text(value):
    text = f"{value:+.4f}%"
    if value > 0:
        return color(text, "32;1")  # bright green profit
    if value < 0:
        return color(text, "31")
    return text


def init_db():
    global db
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("""CREATE TABLE IF NOT EXISTS cycles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts_utc TEXT NOT NULL,
        direction TEXT NOT NULL,
        start_usdt REAL NOT NULL,
        final_usdt REAL,
        profit_usdt REAL,
        profit_pct REAL,
        status TEXT NOT NULL
    )""")
    db.commit()


def check_symbols():
    req = urllib.request.Request(EXCHANGE_INFO_URL, headers={"User-Agent": "TriangularArbitrageMonitor/0.1"})
    with urllib.request.urlopen(req, timeout=12) as response:
        payload = json.loads(response.read().decode("utf-8"))
    found = {item["symbol"]: item for item in payload.get("symbols", [])}
    missing = [s for s in SYMBOLS if s not in found]
    inactive = [s for s in SYMBOLS if s in found and found[s].get("status") != "TRADING"]
    if missing or inactive:
        details = []
        if missing:
            details.append("not listed: " + ", ".join(missing))
        if inactive:
            details.append("not trading: " + ", ".join(inactive))
        raise RuntimeError("Required triangle unavailable on this Binance Spot endpoint (" + "; ".join(details) + ").")
    return found


def parse_book(data):
    bids = [(float(p), float(q)) for p, q in data.get("bids", []) if float(q) > 0]
    asks = [(float(p), float(q)) for p, q in data.get("asks", []) if float(q) > 0]
    bids.sort(key=lambda x: x[0], reverse=True)
    asks.sort(key=lambda x: x[0])
    if not bids or not asks:
        return None
    return {"bids": bids[:DEPTH_LEVELS], "asks": asks[:DEPTH_LEVELS], "received": time.monotonic()}


def buy_base(quote_amount, asks, fee_rate):
    """Spend quote asset across ask levels; fee is deducted from received base."""
    remaining = quote_amount
    received_base = 0.0
    for price, available_base in asks:
        take = min(available_base, remaining / price)
        if take <= 0:
            continue
        received_base += take
        remaining -= take * price
        if remaining <= max(1e-12, quote_amount * 1e-12):
            remaining = 0.0
            break
    if remaining > max(1e-10, quote_amount * 1e-9):
        return None
    return received_base * (1.0 - fee_rate)


def sell_base(base_amount, bids, fee_rate):
    """Sell base asset across bid levels; fee is deducted from received quote."""
    remaining = base_amount
    received_quote = 0.0
    for price, available_base in bids:
        take = min(available_base, remaining)
        if take <= 0:
            continue
        received_quote += take * price
        remaining -= take
        if remaining <= max(1e-12, base_amount * 1e-12):
            remaining = 0.0
            break
    if remaining > max(1e-10, base_amount * 1e-9):
        return None
    return received_quote * (1.0 - fee_rate)


def simulate_route(start_usdt, fee_rate):
    """Simulate both complete USDT->asset->asset->USDT routes using visible depth."""
    btcusdt = books.get("BTCUSDT")
    etcusdt = books.get("ETCUSDT")
    etcbtc = books.get("ETCBTC")
    if not all((btcusdt, etcusdt, etcbtc)):
        return []

    # Route 1: USDT -> BTC (buy BTC) -> ETC (buy ETC with BTC) -> USDT (sell ETC).
    btc = buy_base(start_usdt, btcusdt["asks"], fee_rate)
    etc = buy_base(btc, etcbtc["asks"], fee_rate) if btc is not None else None
    final_1 = sell_base(etc, etcusdt["bids"], fee_rate) if etc is not None else None

    # Route 2: USDT -> ETC (buy ETC) -> BTC (sell ETC) -> USDT (sell BTC).
    etc_2 = buy_base(start_usdt, etcusdt["asks"], fee_rate)
    btc_2 = sell_base(etc_2, etcbtc["bids"], fee_rate) if etc_2 is not None else None
    final_2 = sell_base(btc_2, btcusdt["bids"], fee_rate) if btc_2 is not None else None

    results = []
    for name, final in (("USDT>Btc>ETC>USDT", final_1), ("USDT>ETC>BTC>USDT", final_2)):
        if final is None:
            results.append({"direction": name, "final": None, "profit": None, "pct": None,
                            "status": "insufficient visible order-book depth"})
        else:
            profit = final - start_usdt
            results.append({"direction": name, "final": final, "profit": profit,
                            "pct": profit / start_usdt * 100.0, "status": "simulated"})
    return results


async def market_data():
    global connection, last_error
    delay = 1
    while True:
        try:
            connection = "connecting"
            async with websockets.connect(WS_URL, ping_interval=20, ping_timeout=20, close_timeout=5) as ws:
                connection = "connected"
                last_error = ""
                delay = 1
                async for raw in ws:
                    try:
                        message = json.loads(raw)
                        data = message.get("data", {})
                        symbol = data.get("s")
                        if symbol not in SYMBOLS:
                            continue
                        book = parse_book(data)
                        if book:
                            books[symbol] = book
                    except (ValueError, TypeError, KeyError):
                        continue
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            last_error = str(exc)[:100]
            connection = "reconnecting"
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)


def books_ready():
    if not all(s in books for s in SYMBOLS):
        return False, "waiting for all three order books"
    now = time.monotonic()
    ages = [(now - books[s]["received"]) * 1000 for s in SYMBOLS]
    if max(ages) > MAX_BOOK_AGE_MS:
        return False, "stale order book"
    received = [books[s]["received"] for s in SYMBOLS]
    if (max(received) - min(received)) * 1000 > MAX_BOOK_SKEW_MS:
        return False, "order-book time skew"
    return True, "ready"


def render():
    ready, reason = books_ready()
    lines = [
        f"TRIANGULAR ARBITRAGE v{VERSION} | BINANCE SPOT | READ-ONLY SIMULATION",
        f"UTC: {utc_now()} | Start capital: {START_USDT:.2f} USDT | Assumed fee: {FEE_RATE*100:.3f}% per leg",
        f"Connection: {connection} | Max book age: {MAX_BOOK_AGE_MS} ms | Max skew: {MAX_BOOK_SKEW_MS} ms",
        "",
        "SYMBOL   BEST BID          BID QTY       BEST ASK          ASK QTY       AGE",
        "-" * 82,
    ]
    now = time.monotonic()
    for symbol in SYMBOLS:
        book = books.get(symbol)
        if not book:
            lines.append(f"{symbol:<8} waiting for data")
            continue
        age = (now - book["received"]) * 1000
        bp, bq = book["bids"][0]
        ap, aq = book["asks"][0]
        lines.append(f"{symbol:<8} {bp:<17.8g} {bq:<13.6g} {ap:<17.8g} {aq:<13.6g} {age:6.0f} ms")

    lines.extend(["", "TRIANGULAR ROUTES (fees included; visible top-20 depth simulated):", "-" * 82])
    if not ready:
        lines.append("  " + reason)
    else:
        for result in simulate_route(START_USDT, FEE_RATE):
            if result["pct"] is None:
                lines.append(f"  {result['direction']:<24} NO SIGNAL — {result['status']}")
                continue
            pct = pct_text(result["pct"])
            lines.append(f"  {result['direction']:<24} final {result['final']:>12.6f} USDT | "
                         f"profit {result['profit']:+.6f} USDT | {pct}")
            db.execute("""INSERT INTO cycles
                (ts_utc, direction, start_usdt, final_usdt, profit_usdt, profit_pct, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (utc_now(), result["direction"], START_USDT, result["final"],
                 result["profit"], result["pct"], result["status"]))
        db.commit()
    lines.extend([
        "",
        "GREEN % = positive simulated result after assumed fees. RED % = loss.",
        "Simulation only: no API keys, no account access, no orders are sent.",
        "Note: top-20 depth estimate; exchange lot-size/min-notional filters and actual fee discounts are not applied.",
        f"SQLite: {os.path.abspath(DB_PATH)}",
        "Ctrl+C to stop.",
    ])
    if last_error:
        lines.append("Last connection error: " + last_error)
    return "\n".join(lines)


async def dashboard():
    while True:
        print("\033[H\033[2J", end="")
        print(render(), flush=True)
        await asyncio.sleep(DISPLAY_INTERVAL)


async def main():
    print("Checking Binance Spot symbol availability...", flush=True)
    info = await asyncio.to_thread(check_symbols)
    for symbol in SYMBOLS:
        item = info[symbol]
        print(f"  {symbol}: {item.get('status')} ({item.get('baseAsset')}/{item.get('quoteAsset')})")
    init_db()
    tasks = [asyncio.create_task(market_data()), asyncio.create_task(dashboard())]
    try:
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if db:
            db.commit()
            db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception as exc:
        print("Startup error:", exc)
        raise
